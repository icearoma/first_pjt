@echo off
x:
cd x:\02_JOB\1002_eai_pi_exe\sap_pi_exe_j6_j8\
 
:INPUT
ECHO =========================================
ECHO   0:EXIST
ECHO =========================================
ECHO   1:DEV ESR
ECHO   2:DEV IB
ECHO   3:QA ESR
ECHO   4:QA IB
ECHO   5:PROD ESR
ECHO   6:PROD IB
ECHO =========================================
 
set /p exeid=     ��������Է�:
 
if %exeid% equ 1 (
ECHO   1:DEV ESR
call .\jre8\bin\javaws -wait .\jnlp\0101_dev_esr.jnlp
) else if %exeid% equ 2 (
ECHO   2:DEV ID
call .\jre8\bin\javaws -wait .\jnlp\0101_dev_id.jnlp
) else if %exeid% equ 3 (
ECHO   3:QA ESR
call .\jre8\bin\javaws -wait .\jnlp\0201_qa_esr.jnlp
) else if %exeid% equ 4 (
ECHO   4:QA ID
call .\jre8\bin\javaws -wait .\jnlp\0201_qa_id.jnlp
)else if %exeid% equ 5 (
ECHO   5:PROD ESR
call .\jre8\bin\javaws -wait .\jnlp\0301_prod_esr.jnlp
)else if %exeid% equ 6 (
ECHO   6:PROD ID
call .\jre8\bin\javaws -wait .\jnlp\0301_prod_id.jnlp
)else ( echo "�߸������Ͽ���." )
 
rem echo "exeid [%exeid%]"

if %exeid% neq 0 (
	if %exeid% neq exit (
		if %exeid% neq quit (
			set exeid=
			goto INPUT
		)
	)
)
 
exit

