
@echo off
x:
rem cd x:\02_JOB\1002_eai_pi_exe\sap_pi_exe_j6_j8\
cd %~dp0

:INPUT
ECHO =========================================
ECHO   0:EXIST
ECHO =========================================
ECHO   1:DEV ESR
ECHO   2:DEV IB
ECHO   3:QA ESR
ECHO   4:QA IB
ECHO   5:PROD ESR
ECHO   6:PROD IB
ECHO   A:ESR repository.jnlp
ECHO   B:IB directory.jnlp
ECHO   11:TNS DEV ESR (han2026)
ECHO   22:TNS DEV IB
ECHO   33:TNS QA ESR
ECHO   44:TNS QA IB
ECHO   55:TNS PROD ESR
ECHO   66:TNS PROD IB (han2026)
ECHO =========================================
 
set /p exeid=     ��������Է�:
 
if %exeid% equ 1 (
ECHO   1:DEV ESR
call .\jre8\bin\javaws -wait .\jnlp\0101_dev_esr.jnlp
) else if %exeid% equ 2 (
ECHO   2:DEV ID
call .\jre8\bin\javaws -wait .\jnlp\0101_dev_id.jnlp
) else if %exeid% equ 3 (
ECHO   3:QA ESR
call .\jre8\bin\javaws -wait .\jnlp\0201_qa_esr.jnlp
) else if %exeid% equ 4 (
ECHO   4:QA ID
call .\jre8\bin\javaws -wait .\jnlp\0201_qa_id.jnlp
)else if %exeid% equ 5 (
ECHO   5:PROD ESR
call .\jre8\bin\javaws -wait .\jnlp\0301_prod_esr.jnlp
)else if %exeid% equ 6 (
ECHO   6:PROD ID
call .\jre8\bin\javaws -wait .\jnlp\0301_prod_id.jnlp
)else if /I "%exeid%"=="A" (
ECHO   A:ESR repository.jnlp
move /Y C:\Users\nh2095002\Downloads\repository.jnlp X:\02_JOB\1002_eai_pi_exe\sap_pi_exe_j6_j8\jnlp
del /Q "C:\Users\nh2095002\Downloads\repository (*.jnlp)"
call .\jre8\bin\javaws -wait .\jnlp\repository.jnlp
)else if /I "%exeid%"=="B" (
ECHO   B:IB directory.jnlp
rem move /Y C:\Users\nh2095002\Downloads\directory.jnlp X:\02_JOB\1002_eai_pi_exe\sap_pi_exe_j6_j8\jnlp
rem del /Q "C:\Users\nh2095002\Downloads\directory (*.jnlp)"
rem del /Q "C:\Users\nh2095002\Downloads\directory*.jnlp"
call .\jre8\bin\javaws -wait .\jnlp\directory.jnlp
)else if %exeid% equ 11 (
ECHO   11:TNS DEV ESR
call .\jre8\bin\javaws -wait .\jnlp\TNS_dev_esr.jnlp
) else if %exeid% equ 22 (
ECHO   22:TNS DEV ID
call .\jre8\bin\javaws -wait .\jnlp\TNS_dev_id.jnlp
) else if %exeid% equ 33 (
ECHO   33:TNS QA ESR
call .\jre8\bin\javaws -wait .\jnlp\TNS_qa_esr.jnlp
) else if %exeid% equ 44 (
ECHO   44:TNS QA ID
call .\jre8\bin\javaws -wait .\jnlp\TNS_qa_id.jnlp
)else if %exeid% equ 55 (
ECHO   55:TNS PROD ESR
call .\jre8\bin\javaws -wait .\jnlp\TNS_prod_esr.jnlp
)else if %exeid% equ 66 (
ECHO   66:TNS PROD ID
call .\jre8\bin\javaws -wait .\jnlp\TNS_prod_id.jnlp
)else ( echo "�߸������Ͽ���." )
 
rem echo "exeid [%exeid%]"

if %exeid% neq 0 (
	if %exeid% neq exit (
		if %exeid% neq quit (
			set exeid=
			goto INPUT
		)
	)
)
 
exit

