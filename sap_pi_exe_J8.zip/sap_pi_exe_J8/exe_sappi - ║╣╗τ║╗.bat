
@echo off
x:
rem cd x:\02_JOB\1002_eai_pi_exe\sap_pi_exe_j6_j8\
cd %~dp0
 
:INPUT
ECHO =========================================
ECHO   0:EXIST
ECHO =========================================
ECHO   1:DEV ESR
ECHO   2:DEV IB
ECHO   3:QA ESR
ECHO   4:QA IB
ECHO   5:PROD ESR
ECHO   6:PROD IB
ECHO   A:ESR repository.jnlp
ECHO   B:IB directory.jnlp


ECHO =========================================
 
set /p exeid=     ��������Է�:
 
if %exeid% equ 1 (
ECHO   1:DEV ESR
call .\jre8\bin\javaws -wait .\jnlp\0101_dev_esr.jnlp
) else if %exeid% equ 2 (
ECHO   2:DEV ID
call .\jre8\bin\javaws -wait .\jnlp\0101_dev_id.jnlp
) else if %exeid% equ 3 (
ECHO   3:QA ESR
call .\jre8\bin\javaws -wait .\jnlp\0201_qa_esr.jnlp
) else if %exeid% equ 4 (
ECHO   4:QA ID
call .\jre8\bin\javaws -wait .\jnlp\0201_qa_id.jnlp
)else if %exeid% equ 5 (
ECHO   5:PROD ESR
call .\jre8\bin\javaws -wait .\jnlp\0301_prod_esr.jnlp
)else if %exeid% equ 6 (
ECHO   6:PROD ID
call .\jre8\bin\javaws -wait .\jnlp\0301_prod_id.jnlp
)else if %exeid% equ A (
ECHO   A:ESR repository.jnlp
call .\jre8\bin\javaws -wait .\jnlp\repository.jnlp
)else if %exeid% equ B (
ECHO   B:IB directory.jnlp
call .\jre8\bin\javaws -wait .\jnlp\directory.jnlp
)else if %exeid% equ 11 (
ECHO   11:TNS DEV ESR
call .\jre8\bin\javaws -wait .\jnlp\0101_dev_esr.jnlp
) else if %exeid% equ 22 (
ECHO   22:TNS DEV ID
call .\jre8\bin\javaws -wait .\jnlp\0101_dev_id.jnlp
) else if %exeid% equ 33 (
ECHO   33:TNS QA ESR
call .\jre8\bin\javaws -wait .\jnlp\0201_qa_esr.jnlp
) else if %exeid% equ 44 (
ECHO   44:TNS QA ID
call .\jre8\bin\javaws -wait .\jnlp\0201_qa_id.jnlp
)else if %exeid% equ 55 (
ECHO   55:TNS PROD ESR
call .\jre8\bin\javaws -wait .\jnlp\0301_prod_esr.jnlp
)else if %exeid% equ 66 (
ECHO   66:TNS PROD ID
call .\jre8\bin\javaws -wait .\jnlp\0301_prod_id.jnlp
)else ( echo "�߸������Ͽ���." )
 
rem echo "exeid [%exeid%]"

if %exeid% neq 0 (
	if %exeid% neq exit (
		if %exeid% neq quit (
			set exeid=
			goto INPUT
		)
	)
)
 
exit

